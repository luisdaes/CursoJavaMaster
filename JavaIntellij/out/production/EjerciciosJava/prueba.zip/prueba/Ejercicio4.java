package prueba;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Ejercicio4 {

    public static void main(String[] args) {

        String nombreEmpresa = "Heisohn";
        String extraerPalabra = "soh";
        int initIndex = 0;
        int endIndex = 0;
        Pattern word = Pattern.compile(extraerPalabra);
        Matcher match = word.matcher(nombreEmpresa);

        while (match.find()) {
            initIndex = match.start();
            endIndex = match.end();
        }
        String palabraExtraida = nombreEmpresa.substring(initIndex, endIndex);
        System.out.println(palabraExtraida.equals(extraerPalabra));

    }

}
