package prueba;

public class Ejercicio2 {

    public static void main(String[] args) {

        int numero1 = 22, numero2 = 20, numero3 = 11, max = 0;

        max = (numero1 > numero2) ? numero1 : numero2;
        max = (max > numero3)  ? max  : numero3;

        System.out.println("El mayor es: " + max);
    }
}
