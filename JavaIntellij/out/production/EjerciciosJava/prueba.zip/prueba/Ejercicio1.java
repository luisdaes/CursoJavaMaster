package prueba;

import java.util.*;

public class Ejercicio1 {

    public static void main(String[] args) {

        int[] array = new int[]{1, 0, 1, 0, 0, 0, 1, 1};
        int per = 1;

        for (int i = 0; i < per; i++) {

            int val1 = 0;
            int val2 = 0;

            for (int k = 0; k < array.length; k++) {
                if (k < array.length - 1) {
                    if (array[k + 1] == val1) {
                        val1 = array[k];
                        array[k] = 0;
                    } else {
                        val1 = array[k];
                        array[k] = 1;
                    }
                } else {
                    if (val1 == val2) {
                        array[k] = 0;
                    } else {
                        array[k] = 1;
                    }
                }
            }
        }
        System.out.println(Arrays.toString(Arrays.stream(array).toArray()));

    }

}
