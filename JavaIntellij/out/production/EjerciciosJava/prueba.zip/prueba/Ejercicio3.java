package prueba;

import java.util.ArrayList;

public class Ejercicio3 {

    public static void main(String[] args) {

        int[] numeros = new int[]{15, 7, 2, 1, 5, 9, 8, 7, 24, 50};

        ArrayList<Integer> pares = new ArrayList<>();
        ArrayList<Integer> impares = new ArrayList<>();

        for (int i = 0; i <= numeros.length - 1; i++) {
            if (numeros[i] % 2 == 0) {
                pares.add(numeros[i]);
            } else if (numeros[i] % 2 != 0) {
                impares.add(numeros[i]);
            }
        }
        impares.sort(((o1, o2) -> o1.compareTo(o2)));
        pares.addAll(impares);
        System.out.println(pares);

    }

}
